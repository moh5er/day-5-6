<?php
// معلومات الاتصال
$host = 'localhost'; // أو اسم السيرفر
$user = 'root';      // اسم المستخدم
$password = '';      // كلمة المرور (تأكد من أنها صحيحة)
$dbname = 'user_db'; // اسم قاعدة البيانات

// إنشاء الاتصال
$con = mysqli_connect($host, $user, $password, $dbname);

// التحقق من الاتصال
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

