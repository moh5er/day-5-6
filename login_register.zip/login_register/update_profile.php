<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

// Initialize message array to store errors or success messages
$message = [];

if (isset($_POST['update_profile'])) {
    // Check if the form inputs exist and process them
    if (isset($_POST['update_name'])) {
        $update_name = mysqli_real_escape_string($con, $_POST['update_name']);
    }
    if (isset($_POST['update_email'])) {
        $update_email = mysqli_real_escape_string($con, $_POST['update_email']);
    }

    // Handle password update only if the fields are set
    if (isset($_POST['update_pass']) && isset($_POST['old_pass']) && isset($_POST['new_pass']) && isset($_POST['confirm_pass'])) {
        $old_pass = mysqli_real_escape_string($con, md5($_POST['old_pass']));
        $update_pass = mysqli_real_escape_string($con, md5($_POST['update_pass']));
        $new_pass = mysqli_real_escape_string($con, md5($_POST['new_pass']));
        $confirm_pass = mysqli_real_escape_string($con, md5($_POST['confirm_pass']));
    }

    // Image Upload Handling
    if (isset($_FILES['update_pic']['name']) && $_FILES['update_pic']['name'] != '') {
        $image_name = $_FILES['update_pic']['name'];
        $image_tmp_name = $_FILES['update_pic']['tmp_name'];
        $image_size = $_FILES['update_pic']['size'];
        $image_error = $_FILES['update_pic']['error'];

        // Check if image size is valid and file type is allowed
        if ($image_size <= 1000000 && ($image_error == 0)) {
            $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
            $image_ext = strtolower($image_ext);
            $allowed = array('jpg', 'jpeg', 'png');

            if (in_array($image_ext, $allowed)) {
                // Generate new name for the image to avoid conflicts
                $new_image_name = uniqid('', true) . '.' . $image_ext;
                $image_upload_path = 'images/' . $new_image_name;
                move_uploaded_file($image_tmp_name, $image_upload_path);
            } else {
                $message[] = 'Only JPG, JPEG, and PNG files are allowed';
            }
        } else {
            $message[] = 'Image is too large or there was an error uploading';
        }
    }

    // Check if the user wants to update the profile
    if (!empty($update_name) && !empty($update_email)) {
        $update_query = "UPDATE `user_form` SET name = '$update_name', email = '$update_email'";

        // If image is uploaded, update the image as well
        if (isset($new_image_name)) {
            $update_query .= ", image = '$new_image_name'";
        }

        // If password fields are not empty, handle password update
        if (isset($old_pass) && isset($new_pass) && isset($confirm_pass)) {
            // Assuming you have $fetch fetched earlier
            if ($old_pass != $fetch['password']) {
                $message[] = 'Old password does not match';
            } elseif ($new_pass != $confirm_pass) {
                $message[] = 'New passwords do not match';
            } else {
                $update_query .= ", password = '$new_pass'";
            }
        }

        // Add the WHERE condition for the user
        $update_query .= " WHERE id = '$user_id'";

        if (mysqli_query($con, $update_query)) {
            $message[] = 'Profile updated successfully';
        } else {
            $message[] = 'Failed to update profile';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="update.css">
</head>
<body>
    
 <div class="update-profile">
 <?php
            // Fetch the user's current details from the database
            $select = mysqli_query($con, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
            
            if (mysqli_num_rows($select) > 0) {
                $fetch = mysqli_fetch_assoc($select);
?>
             
            <form action="" method="post" enctype="multipart/form-data">
                <!-- Display user image -->
                <?php
                  if ($fetch['image'] == '') {
                    echo '<img src="Untitled.png">';
                  } else {
                    echo '<img src="images/'.$fetch['image'].'" alt="Profile Picture">';
                  }
                ?>
             
                <div class="inputBox">
                    <span>Username:</span>
                    <input class="box" type="text" name="update_name" value="<?php echo $fetch['name']; ?>" required>

                    <span>Your Email:</span>
                    <input class="box" type="email" name="update_email" value="<?php echo $fetch['email']; ?>" required>

                    <span>Update Your Picture:</span>
                    <input class="box" type="file" name="update_pic" accept="image/jpg, image/jpeg, image/png">
                </div>

                <div class="inputBox">
                    <span>Old Password:</span>
                    <input type="password" name="old_pass" placeholder="Enter your current password" class="box">

                    <span>New Password:</span>
                    <input type="password" name="new_pass" placeholder="Enter new password" class="box">

                    <span>Confirm Password:</span>
                    <input type="password" name="confirm_pass" placeholder="Confirm your new password" class="box">
                </div>

                <input type="submit" value="Update Profile" name="update_profile">
                <a href="home.php" class="delete-btn">Go Back</a>
            </form>

            <?php
            } else {
                echo '<p class="message error">User not found. Please login again.</p>';
            }

            // Display success or error messages
            if (isset($message)) {
                foreach ($message as $msg) {
                    echo '<p class="message">'. $msg .'</p>';
                }
            }
            ?>

        </div>

</body>
</html>
