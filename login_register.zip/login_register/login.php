<?php
include 'config.php';
session_start();

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, md5($_POST['password'])); // أو استخدام password_hash بدلاً من md5()

    // التحقق إذا كان المستخدم موجود
    $select = mysqli_query($con, "SELECT * FROM `user_form` WHERE email = '$email'") or die('Query failed');
    
    if (mysqli_num_rows($select) > 0) {
        // إذا وجد المستخدم
        $row = mysqli_fetch_assoc($select);
        // التحقق من كلمة المرور
        if ($pass == $row['password']) {
            $_SESSION['user_id'] = $row['id']; // تخزين ID المستخدم في الجلسة
            header('location:home.php'); // إعادة توجيه المستخدم إلى الصفحة الرئيسية
        } else {
            $message[] = 'Incorrect password';
        }
    } else {
        $message[] = 'User not found';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
   
    <div class="form-container">
        <form action="login.php" method="post">
            <h2>Login</h2>
            <?php
            // عرض الرسائل إذا كانت موجودة
            if (isset($message)) {
                foreach ($message as $msg) {
                    echo '<p class="msg">'.$msg.'</p>';
                }
            }
            ?>
            <input type="email" name="email" placeholder="Enter email" required>
            <input type="password" name="password" placeholder="Enter password" required>
            <input type="submit" name="submit" value="Login" class="btn">
            <p>Don't have an account? <a href="register.php">Register</a></p>
        </form>
    </div>

</body>
</html>
