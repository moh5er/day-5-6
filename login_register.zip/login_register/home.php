<?php
include 'config.php';
session_start();

// التحقق مما إذا كان المستخدم مسجلاً للدخول
$user_id = $_SESSION['user_id'];
if (!isset($user_id)) {
    header('location:login.php');
    exit();  // يجب إضافة exit() بعد header لتوقف تنفيذ السكربت
}

// إذا كان المستخدم قد ضغط على رابط الخروج
if (isset($_GET['logout'])) {
    session_unset();  // إزالة كل المتغيرات في الجلسة
    session_destroy();  // تدمير الجلسة
    header('Location: login.php');  // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول
    exit();  // يجب إضافة exit() بعد header
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Home</title>
</head>
<body>
    <div class="container">
        <div class="profile">
            <?php
            // استعلام لاختيار بيانات المستخدم بناءً على معرف الجلسة
            $select = mysqli_query($con, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
            if (mysqli_num_rows($select) > 0) {
                $fetch = mysqli_fetch_assoc($select);
            }
            if($fetch['image'] == ''){
                echo '<img src="Untitled.png">';

            }else{
                echo '<img src="images/'.$fetch['image'].'"';
            }
            ?>
            <h3><br><?php echo $fetch['name']; ?></h3><h3><br>
            <a href="update_profile.php" class="btn">Update Profile</a><br>
            <a href="home.php?logout=<?php echo $user_id; ?>" class="delete-btn">Logout</a>
            <p>new <a href="login.php">login</a> or 
            <a href="register.php">register</a></p>
        </div>
    </div>
</body>
</html>
