<?php
include 'config.php';

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $pass = mysqli_real_escape_string($con, md5($_POST['password']));
    $cpass = mysqli_real_escape_string($con, md5($_POST['cpassword']));
    $image = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];

    // التأكد من وجود مجلد رفع الصور
    if (!file_exists('uploaded_img')) {
        mkdir('uploaded_img', 0777, true);  // إنشاء المجلد إذا لم يكن موجود
    }

    $image_folder = 'uploaded_img/' . $image; // المسار إلى المجلد الذي سيتم رفع الصورة فيه

    // التحقق إذا كان المستخدم موجود مسبقًا
    $select = mysqli_query($con, "SELECT * FROM `user_form` WHERE email = '$email'") or die('Query failed');
    
    if (mysqli_num_rows($select) > 0) {
        $message[] = 'User already exists';
    } else {
        // التحقق من تطابق كلمة المرور مع التأكيد
        if ($pass != $cpass) {
            $message[] = 'Confirm password does not match!';
        } elseif ($image_size > 2000000) {
            $message[] = 'Image size should be less than 2MB!';
        } elseif (!in_array(strtolower(pathinfo($image, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png'])) {
            $message[] = 'Only JPG, JPEG, and PNG images are allowed!';
        } else {
            // رفع الصورة إلى المجلد
            if (move_uploaded_file($image_tmp_name, $image_folder)) {
                // إدخال البيانات في قاعدة البيانات
                $insert = mysqli_query($con, "INSERT INTO `user_form` (name, email, password, image) 
                                             VALUES('$name', '$email', '$pass', '$image')") or die('Query failed');

                if ($insert) {
                    $message[] = 'User created successfully';
                    header('Location: login.php');
                } else {
                    $message[] = 'Failed to create user';
                }
            } else {
                $message[] = 'Failed to upload image';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
    <div class="form-container">
        <h3>Register Now</h3>
        <?php
        if (isset($message)) {
            foreach ($message as $msg) {
                echo '<p class="msg">'.$msg.'</p>';
            }
        }
        ?>
        <form action="register.php" method="post" enctype="multipart/form-data">
            <input type="text" name="name" placeholder="Enter username" required>
            <input type="email" name="email" placeholder="Enter email" class="box" required>
            <input type="password" name="password" placeholder="Enter password" class="box" required>
            <input type="password" name="cpassword" placeholder="Confirm password" class="box" required>
            <input type="file" name="image" class="box" accept="image/jpg, image/jpeg, image/png" required>
            <input type="submit" name="submit" value="Register" class="btn">
            <p>Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>
</body>
</html>
